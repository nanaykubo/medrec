module.exports = {
	JWT_SECRET: 'apiauthenticationsecret'
}