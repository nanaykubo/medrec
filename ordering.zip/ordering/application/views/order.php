<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Design System for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Argon Design System - Free Design System for Bootstrap 4</title>
  <!-- Favicon -->
  <link href="<?php echo base_url()?>/assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="<?php echo base_url()?>/assets/vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="<?php echo base_url()?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="<?php echo base_url()?>/assets/css/argon.css?v=1.0.1" rel="stylesheet">
  <!-- Docs CSS -->
  <link type="text/css" href="<?php echo base_url()?>/assets/css/docs.min.css" rel="stylesheet">
</head>

<body>
  <main>
    <section class="section section-shaped section-lg">
      <div class="shape shape-style-1 bg-gradient-default">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="container pt-lg-md">
        <div class="row justify-content-center">
          <div class="col-lg-5">
            <div class="card bg-secondary shadow border-0">
                <!-- <div class="card-header bg-white pb-5">
                  <div class="text-muted text-center mb-3">
                    <small>Sign up with</small>
                  </div>
                  <div class="text-center">
                    <a href="#" class="btn btn-neutral btn-icon mr-4">
                      <span class="btn-inner--icon">
                        <img src="../assets/img/icons/common/github.svg">
                      </span>
                      <span class="btn-inner--text">Github</span>
                    </a>
                    <a href="#" class="btn btn-neutral btn-icon">
                      <span class="btn-inner--icon">
                        <img src="../assets/img/icons/common/google.svg">
                      </span>
                      <span class="btn-inner--text">Google</span>
                    </a>
                  </div>
                </div> -->
              <div class="card-body px-lg-5 py-lg-5">
                <div class="text-center text-muted mb-4">
                  <small>Order Your Pizza Now</small>
                </div>
                <form role="form" method="post" action="<?php echo base_url('home/submit') ?>">
                  <div class="pizza">
                    <div class="form-group">
                      <div class="input-group input-group-alternative mb-3">
                        <select name="type" class="form-control" placeholder="Name" type="text" required>
                          <option  disabled value="" selected hidden>Pizza Type</option>
                          <option>Hawaian</option>
                          <option>Chicken Fajita</option>
                          <option>Custom</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="input-group input-group-alternative mb-3">
                        <select name="size" class="form-control" placeholder="Name" type="text" required>
                          <option  disabled value="" selected hidden>Size</option>
                          <option>Small</option>
                          <option>Medium</option>
                          <option>Large</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="input-group input-group-alternative mb-3">
                        <select name="crust" class="form-control" placeholder="Name" type="text" required>
                          <option disabled value="" selected hidden>Crust</option>
                          <option>Thin</option>
                          <option>Chicken Fajita</option>
                          <option>Custom</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="text-muted font-italic">
                    <small>password strength:
                      <span class="text-success font-weight-700">strong</span>
                    </small>
                  </div>
                  <div class="text-center">
                    <button type="submit" class="btn btn-primary mt-4">Submit Order</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <!-- Core -->
  <script src="<?php echo base_url()?>/assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url()?>/assets/vendor/popper/popper.min.js"></script>
  <script src="<?php echo base_url()?>/assets/vendor/bootstrap/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>/assets/vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="<?php echo base_url()?>/assets/js/argon.js?v=1.0.1"></script>
</body>

</html>